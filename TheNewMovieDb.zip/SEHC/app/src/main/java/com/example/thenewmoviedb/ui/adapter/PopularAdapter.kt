//package com.example.thenewmoviedb.ui.adapter
//
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import androidx.recyclerview.widget.RecyclerView
//import com.example.thenewmoviedb.R
//
//class PopularAdapter: RecyclerView.Adapter<PopularAdapter.MovieViewHolder> {
//
//    class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
//        return MovieViewHolder(
//            LayoutInflater.from(parent.context).inflate(R.layout.item_movie, parent, false)
//        )
//    }
//
//    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
//
//    }
//
//    override fun getItemCount(): Int {
//        return 25
//    }
//}